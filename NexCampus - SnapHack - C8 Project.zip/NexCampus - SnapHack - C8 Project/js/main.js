
// main.js — handles student & college auth, events, UI linking

// =============================
// 🔐 SESSION HELPERS
// =============================
function setUser(user, type) {
  localStorage.setItem("loggedInUser", JSON.stringify(user));
  localStorage.setItem("userType", type);
}

function getUser() {
  return JSON.parse(localStorage.getItem("loggedInUser"));
}

function getUserType() {
  return localStorage.getItem("userType");
}

function logout() {
  localStorage.removeItem("loggedInUser");
  localStorage.removeItem("userType");
  window.location.href = "index.html";
}

// =============================
// 🧾 FORM HANDLERS
// =============================

async function register(event, type) {
  event.preventDefault();
  const form = event.target;
  const data = Object.fromEntries(new FormData(form));

  try {
    const res = await fetch(`/api/${type}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const result = await res.json();
    if (res.ok) {
      alert(`${type} registered successfully`);
      window.location.href = `${type} login.html`;
    } else {
      alert(result.message || "Registration failed");
    }
  } catch (err) {
    alert("Error connecting to server.");
  }
}

async function login(event, type) {
  event.preventDefault();
  const form = event.target;
  const data = Object.fromEntries(new FormData(form));

  try {
    const res = await fetch(`/api/${type}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const user = await res.json();
    if (res.ok) {
      setUser(user, type);
      window.location.href = type === "student" ? "profile.html" : "College Events Public.html";
    } else {
      alert(user.message || "Login failed");
    }
  } catch (err) {
    alert("Error connecting to server.");
  }
}

// =============================
// 📅 EVENT POSTING (College)
// =============================

async function postEvent(event) {
  event.preventDefault();
  const form = event.target;
  const data = Object.fromEntries(new FormData(form));
  const user = getUser();

  data["college-name"] = user.college_name || user.name;

  try {
    const res = await fetch("/api/events", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const result = await res.json();
    if (res.ok) {
      alert("Event posted successfully");
      form.reset();
      loadEvents();
    } else {
      alert(result.message || "Failed to post event");
    }
  } catch (err) {
    alert("Error posting event");
  }
}

// =============================
// 📥 LOAD EVENTS (Student View)
// =============================

async function loadEvents() {
  const container = document.getElementById("eventList");
  if (!container) return;

  try {
    const res = await fetch("/api/events");
    const events = await res.json();
    container.innerHTML = "";

    events.forEach(evt => {
      const div = document.createElement("div");
      div.className = "event";
      div.dataset.category = evt.type;
      div.innerHTML = `
        <h3>${evt["event_title"]}</h3>
        <p><strong>College:</strong> ${evt["college-name"]}</p>
        <p><strong>Date:</strong> ${evt.date}</p>
        <small>Description: ${evt.description}</small>
      `;
      container.appendChild(div);
    });
  } catch (err) {
    container.innerHTML = "<p>Error loading events</p>";
  }
}

// =============================
// 🔍 FILTER EVENTS (Student)
// =============================

function filterEvents() {
  const searchInput = document.getElementById("searchInput");
  const categoryFilter = document.getElementById("categoryFilter");
  const events = document.querySelectorAll(".event");

  const searchValue = searchInput?.value.toLowerCase() || "";
  const selectedCategory = categoryFilter?.value || "all";

  events.forEach(event => {
    const title = event.querySelector("h3").textContent.toLowerCase();
    const category = event.getAttribute("data-category");

    const matchesSearch = title.includes(searchValue);
    const matchesCategory = selectedCategory === "all" || category === selectedCategory;

    event.style.display = matchesSearch && matchesCategory ? "block" : "none";
  });
}

// =============================
// 🔗 INIT ON PAGE LOAD
// =============================

document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");

  if (form && form.classList.contains("registration-form")) {
    const type = location.href.includes("student") ? "student" : "college";
    form.addEventListener("submit", e => register(e, type));
  }

  if (form && form.classList.contains("login-form")) {
    const type = location.href.includes("student") ? "student" : "college";
    form.addEventListener("submit", e => login(e, type));
  }

  if (form && form.classList.contains("event-form")) {
    const userType = getUserType();
    if (userType === "college") {
      form.querySelectorAll("input, textarea").forEach(i => i.disabled = false);
      form.addEventListener("submit", postEvent);
    }
  }

  if (document.getElementById("eventList")) {
    loadEvents();
  }

  const searchInput = document.getElementById("searchInput");
  const categoryFilter = document.getElementById("categoryFilter");
  searchInput?.addEventListener("input", filterEvents);
  categoryFilter?.addEventListener("change", filterEvents);
});
